import { SeatNamePipe } from './seatname.pipe';

describe('SeatnamePipe', () => {
  it('create an instance', () => {
    const pipe = new SeatNamePipe();
    expect(pipe).toBeTruthy();
  });
});
